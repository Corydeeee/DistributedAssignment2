//
//  splitutility.h
//  MapperX
//
//  Created by Warren Zajac on 2019-11-29.
//  Copyright © 2019 Zajac. All rights reserved.
//

#ifndef splitutility_h
#define splitutility_h


char * getSplitFilename(int count);
int splitfile(char *fNameInput);


#endif /* splitutility_h */
